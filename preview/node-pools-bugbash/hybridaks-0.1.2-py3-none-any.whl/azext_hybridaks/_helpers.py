# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
# pylint: disable=bad-continuation


def get_resource_id(
    cmd, resource_group_name, provider_name_space, resource_type, resource
):
    """
    Gets the resource id for the resource if name is given.
    """
    from azure.cli.core.commands.client_factory import get_subscription_id
    from msrestazure.tools import is_valid_resource_id, resource_id

    if resource is None or is_valid_resource_id(resource):
        return resource
    return resource_id(
        subscription=get_subscription_id(cmd.cli_ctx),
        resource_group=resource_group_name,
        namespace=provider_name_space,
        type=resource_type,
        name=resource,
    )
