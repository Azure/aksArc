# Description

This resource will manage the remote desktop administration settings on a computer.
This includes whether remote desktop connections are allowed or denied and whether
network level authentication is required.
